package com.net.changepage;

public interface Pageintr {
	public String getpagecontent(int page,int maxn,String s);
}
