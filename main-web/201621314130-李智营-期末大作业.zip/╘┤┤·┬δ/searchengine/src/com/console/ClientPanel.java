package com.console;

import javax.swing.JPanel;

public class ClientPanel extends Panelabs{
	public ClientPanel() {
	}

}
