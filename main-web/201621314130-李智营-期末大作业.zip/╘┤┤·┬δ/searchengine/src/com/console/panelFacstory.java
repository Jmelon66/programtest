package com.console;

import java.awt.Component;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class panelFacstory{
	public panelFacstory() {
	}
	public Component getWebmagic() {
		// TODO Auto-generated method stub
		Webmagmicpanel w=new Webmagmicpanel();
		return w;
	}
	
}
