$(document).ready(function(){
			var i=$('<div></div>')
			i.append("12345")
		$(".body2").append(i);
   });