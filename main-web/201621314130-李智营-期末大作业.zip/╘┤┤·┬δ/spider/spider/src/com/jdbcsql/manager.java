package com.jdbcsql;

import web.process;

public class manager {
	public static void save(process p) {
		
	}
}
